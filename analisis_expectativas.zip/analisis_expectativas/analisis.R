library(tidyverse)


data_ms <- readxl::read_excel("./data/data.xlsx", sheet = "data_expect")
expect_by_group <- readxl::read_excel("./data/data.xlsx")

data_ms <- data_ms %>%
  mutate(dl4_ipc = 100 * (IPC / dplyr::lag(IPC,12) - 1),
         dev_pos = pmax(dl4_ipc - meta, 0),
         dev_neg = pmax(meta - dl4_ipc, 0),
         mas_meta = factor(dl4_ipc > meta)) %>%
  filter(!is.na(dl4_ipc))


# Gráfico comparativo -----------------------------------------------------
# Expectativas, inflación y meta

data_ms |> 
  ggplot(aes(
    x = dl4_ipc, 
    y = exp_inf, 
    color = mas_meta
  )) +
    geom_point() +  # Puntos coloreados según mas_meta
    geom_smooth(method = "lm", se = FALSE, aes(group = mas_meta), size = 0.7) +  # Línea de regresión por categoría
    labs(
      title = NULL,
      x = "Inflación Interanual",
      y = "Expectativas de Inflación",
      color = "Inflación > Meta"
    ) +
    theme_minimal() +
    theme(
      legend.position = c(0.2,0.8), #"bottom", 
      panel.grid.major = element_line(color = "gray", linetype = 3, size = 0.1),
      panel.grid.minor = element_line(color = "gray", linetype = 3, size = 0.1),
      axis.text = element_text(size = 7),  # Tamaño del texto de los ejes
      axis.title = element_text(size = 7),  # Tamaño del texto de los títulos de los ejes
      strip.text = element_text(size = 7),  # Tamaño del texto en los paneles
      legend.text = element_text(size = 7),  # Tamaño del texto de la leyenda
      panel.border = element_rect(color = NA, fill = NA, size = 0.1), 
      legend.title = element_blank(),                   # Elimina el título de la leyenda
      legend.background = element_blank()              # Elimina el fondo/borde de la leyenda
    )




# Estimación de modelo ----------------------------------------------------
data_ms <- data_ms %>%
  mutate(dl4_ipc = 100 * (IPC / dplyr::lag(IPC,12) - 1),
         dev_pos = pmax(dl4_ipc - meta, 0),
         dev_neg = pmax(meta - dl4_ipc, 0))  %>%
  filter(!is.na(dl4_ipc))

model_asi <- lm(exp_inf ~ dev_pos + dev_neg, data = data_ms)
summary(model_asi)$coefficients


#                                                     TAREA ---------------
# 
# seria esto que se hizo para la expectativa globales, repetirlo para casa uno. tener un 
# panel grafico de esas por grupos arriba y la tabla con estos dos coeficientes debajo
# ---------------------------------------------------------
# imagina esta columna es la total, agregarle una columan con este resultado para cada serie. 
# Es decir uni. puesto de bolsa
# NOTA: ver tabla de estimacion de las expectativas "estimacion_exp_globales" 


# -----------------------------------------------------------
data_ms2 <- data_ms %>%
  mutate(across(tcn:fyb_price, .fns = ~ (.-lag(., 12)) / lag(., 12) * 100,
                .names = "dl12_{.col}"),
         across(tcn:fyb_price, .fns = ~ (.-lag(., 1)) / lag(., 12) * 100,
                .names = "dl1_{.col}")) %>%
  mutate(dev_pos = pmax(dl12_IPC - meta, 0),
         dev_neg = pmax(meta - dl12_IPC, 0),
         subsidio = if_else(fecha >= as.Date("2022-03-01"), 1, 0)) |> 
  filter(!is.na(dl12_IPC))

model_asi0 <- lm(exp_inf ~ dev_pos + dev_neg + dl12_wti, data = data_ms2)
model_asi1 <- lm(exp_inf ~ dev_pos*subsidio + dev_neg*subsidio + dl12_wti , data = data_ms2)

stargazer::stargazer(model_asi0,model_asi1, type = "text")

